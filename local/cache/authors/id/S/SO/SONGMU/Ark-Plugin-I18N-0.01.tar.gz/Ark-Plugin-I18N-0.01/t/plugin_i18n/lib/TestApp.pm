package TestApp;
use Ark;

use_plugins 'I18N';

1;

