# NAME

Ark::Plugin::I18N - Ark plugin for I18N

# SYNOPSIS

    use Ark::Plugin::I18N;

# DESCRIPTION

Ark::Plugin::I18N is Ark plugin for I18N.

# LICENSE

Copyright (C) Songmu.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# AUTHOR

Daisuke Murase <typester@cpan.org>

Songmu <y.songmu@gmail.com>
