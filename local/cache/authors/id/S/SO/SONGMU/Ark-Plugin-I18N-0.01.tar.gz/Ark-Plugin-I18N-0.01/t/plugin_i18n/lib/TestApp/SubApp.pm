package TestApp::SubApp;
use Ark;

use_plugins 'I18N';

1;
