package TestApp::I18N::en_us;

use strict;
use warnings;

use base qw( TestApp::I18N );

our %Lexicon = (
    'Hello' => 'Yo!'
);

1;
